# sofia/backend/app/models/__init__.py

# Este arquivo está intencionalmente vazio.
# Sua presença transforma o diretório 'models' em um pacote Python,
# permitindo importações diretas dos módulos de modelo (como segment.py, task.py)
# a partir de outras partes da aplicação.

