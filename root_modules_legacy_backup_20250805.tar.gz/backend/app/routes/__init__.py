# sofia/backend/app/models/__init__.py
# Este arquivo está intencionalmente vazio.
# Sua presença transforma o diretório 'models' em um pacote Python,
# permitindo importações diretas dos módulos dentro dele.

